﻿using UnityEngine;
using System.Collections;

public class clickCounter : MonoBehaviour {
	public static int clickCount=0;
	void OnMouseDown(){
		clickCount = clickCount + 1;

	}
}
