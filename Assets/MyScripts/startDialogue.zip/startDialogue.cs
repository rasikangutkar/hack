﻿using UnityEngine;
using System.Collections;

public class startDialogue : MonoBehaviour {

	public SpriteRenderer r;
	void Start(){
		
	
	}
		void Update(){
		if (clickCounter.clickCount == 0) {
			r.enabled = true;
		} else {
			r.enabled =false;
		}


	}

}
