﻿using UnityEngine;
using System.Collections;

public class dialogueBob1 : MonoBehaviour {
	SpriteRenderer r;
	// Use this for initialization
	void Start () {
	
	}
	
	void Update(){
		if (clickCounter.clickCount == 1) {
			r.enabled = true;
		} else {
			r.enabled =false;
		}


	}
}
